package com.ecommerce;

public class Subject {
	
	private int id;
	private String subject;
	private int teacher_id;
	private int class_id;
	
	
	public Subject(int id, String subject, int teacher_id, int class_id) {
		super();
		this.id = id;
		this.subject = subject;
		this.teacher_id = teacher_id;
		this.class_id = class_id;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getSubject() {
		return subject;
	}
	public void setSubject(String subject) {
		this.subject = subject;
	}
	public int getTeacher_id() {
		return teacher_id;
	}
	public void setTeacher_id(int teacher_id) {
		this.teacher_id = teacher_id;
	}
	public int getClass_id() {
		return class_id;
	}
	public void setClass_id(int class_id) {
		this.class_id = class_id;
	}
	
	
		
	
	

}
