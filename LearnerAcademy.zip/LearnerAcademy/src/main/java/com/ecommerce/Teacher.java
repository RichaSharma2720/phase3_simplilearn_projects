package com.ecommerce;

public class Teacher {
	
	private int id;
	private String teacher_name;
	private String contact;
	private int age;
	public Teacher(int id, String teacher_name, String contact, int age) {
		super();
		this.id = id;
		this.teacher_name = teacher_name;
		this.contact = contact;
		this.age = age;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getTeacher_name() {
		return teacher_name;
	}
	public void setTeacher_name(String teacher_name) {
		this.teacher_name = teacher_name;
	}
	public String getContact() {
		return contact;
	}
	public void setContact(String contact) {
		this.contact = contact;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	
	
	
	
		
	

}
