

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.List;



/**
 * Servlet implementation class ViewClassServlet
 */
@WebServlet("/ViewClassServlet")

public class ViewClassServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ViewClassServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		
		try {
			PrintWriter out=response.getWriter();
			out.print("<html><head><style>\r\n"
					+ "table, th, td {\r\n"
					+ "  border: 1px solid black;\r\n"
					+ "  border-collapse: collapse;\r\n"
					+ "}\r\n"
					+ "\r\n"
					+ "table.center {\r\n"
					+ "  margin-left: auto; \r\n"
					+ "  margin-right: auto;\r\n"
					+ "}\r\n"
					
					
					+ ".button{\r\n"
					+ "  border: 1px solid black;\r\n"
					+"background-color:yellow;margin-left:auto;margin-right:auto;display:block;margin-top:22%;margin-bottom:0%\"\r\n"
					+ "}\r\n");
					
					
out.print("\r\n"
		+ ".add {\r\n"
		+ "  display: flex;\r\n"
		+ "  justify-content: center;\r\n"
		+ "  align-items: center;\r\n"
		+ "  height: 45px;\r\n"
		+ "  width: 130px;\r\n"
		+ "  border: 3px solid green;\r\n"
		+ "  \r\n"
		+ "  margin-left:auto;margin-right:auto;display:block;margin-top:1%;margin-bottom:0%;\r\n"
		+ "  \r\n"
		+ "}\r\n"					
					+ "</style></head><body>");
out.println("<a href=Home.html>Back</a>");
out.println("<a style=margin-left:95% href=Login.html>logout</a>");
out.print("<h1 style=text-align:center;>Class Detail</h1>");

			Connection con=DatabaseConnection.initializeDatabase();
			Statement st=con.createStatement();
			String Query="SELECT * from classes";
			ResultSet resultSet = 	st.executeQuery(Query);
			out.println("<table class=center border=1 width=50% height=50%>");  
            out.println("<tr><th>Id</th><th>Class</th><th>Section</th><th>Action</th><tr>"); 
			while(resultSet.next()) {
					
				out.print("<tr><td>" + resultSet.getInt("id") + "</td><td>" + resultSet.getInt("class_number")
				+ "</td><td>"+ resultSet.getString("section")  
				+"</td><td>"
				
				+ "<form action=ClassReport method=post>"
				+ "<button type=submit name=button value="+resultSet.getInt("id")+">View Report</Button>"
				+ "</form>"
				+ "</td></tr>" );
			}
			
			out.println("</html></body>"); 
			
			resultSet.close();
			st.close();
			con.close();
			
		} catch (Exception e) {
			// TODO: handle exception
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

	public void abc() {
		System.out.println("I got called here");
	}
}
