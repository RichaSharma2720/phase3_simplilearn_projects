

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;

/**
 * Servlet implementation class AddClassServlet
 */

public class AddClassServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AddClassServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		try {
            PrintWriter out = response.getWriter();

            // Initialize the database
			if((request.getParameter("cl_num").equals(null))&& (request.getParameter("C_sec")).equals(null)) {
				out.print("<h1 style=text-color:red>Fill Correct value<h1>");
			}
            Connection con = DatabaseConnection.initializeDatabase();
  
            // Create a SQL query to insert data into demo table
            // demo table consists of two columns, so two '?' is used
            PreparedStatement st = con
                   .prepareStatement("insert into classes (class_number ,section) values(?, ?)");
  
  
            // Same for second parameter
            st.setInt(1, Integer.valueOf(request.getParameter("cl_num")));
            st.setString(2, request.getParameter("C_sec"));
  
            // Execute the insert command using executeUpdate()
            // to make changes in database
            st.executeUpdate();
            
            // Close all the connections
            st.close();
            con.close();
  
            // Get a writer pointer 
            // to display the successful result
            out.print("<html> <body>");
            out.println("<p>Class added Succesfully. To go back please click on below link.");
            out.println("<a href=ViewClassServlet>View Class Details</a>");
            out.println("<a href=Home.html>Go To Home</a>");

            out.println("</body></html>");
        }
        catch (Exception e) {
            e.printStackTrace();
        }
    }

}
