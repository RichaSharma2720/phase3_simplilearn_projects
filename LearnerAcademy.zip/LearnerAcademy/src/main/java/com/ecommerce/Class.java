package com.ecommerce;

public class Class {
	
	private int id;
	private int class_number;
	private String section;
	
	
	public Class(int id, int class_number, String section) {
		super();
		this.id = id;
		this.class_number = class_number;
		this.section = section;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public int getClass_number() {
		return class_number;
	}
	public void setClass_number(int class_number) {
		this.class_number = class_number;
	}
	public String getSection() {
		return section;
	}
	public void setSection(String section) {
		this.section = section;
	}
	public static void forName(String dbDriver) {
		// TODO Auto-generated method stub
		
	}
	
	
	
}
