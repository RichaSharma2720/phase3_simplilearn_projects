package com.ecommerce;

public class Student {
	
	private int student_id;
	private String student_name;
	private String class_id;
	private int age;
	private int contact;
	public Student(int student_id, String student_name, String class_id, int age, int contact) {
		super();
		this.student_id = student_id;
		this.student_name = student_name;
		this.class_id = class_id;
		this.age = age;
		this.contact = contact;
	}
	public int getStudent_id() {
		return student_id;
	}
	public void setStudent_id(int student_id) {
		this.student_id = student_id;
	}
	public String getStudent_name() {
		return student_name;
	}
	public void setStudent_name(String student_name) {
		this.student_name = student_name;
	}
	public String getClass_id() {
		return class_id;
	}
	public void setClass_id(String class_id) {
		this.class_id = class_id;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public int getContact() {
		return contact;
	}
	public void setContact(int contact) {
		this.contact = contact;
	}
	
	
	
	
		

}
